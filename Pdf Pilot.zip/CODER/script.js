// Vortex Lab Intro Animation
document.addEventListener('DOMContentLoaded', () => {
    const intro = document.querySelector('.vortex-intro');
    const mainContent = document.querySelector('.main-content');
    
    // Animation sequence
    setTimeout(() => {
        intro.style.opacity = '0';
        setTimeout(() => {
            intro.style.display = 'none';
            mainContent.style.display = 'block';
            mainContent.style.animation = 'fadeIn 1s ease-out forwards';
            initPDFTools(); // Initialize the PDF tools after intro
        }, 1000);
    }, 3500);
    
    // Skip animation
    document.addEventListener('click', skipAnimation);
    document.addEventListener('keydown', skipAnimation);
    
    function skipAnimation() {
        intro.style.display = 'none';
        mainContent.style.display = 'block';
        mainContent.style.opacity = '1';
        document.removeEventListener('click', skipAnimation);
        document.removeEventListener('keydown', skipAnimation);
        initPDFTools(); // Initialize the PDF tools after skipping intro
    }
});

// Main PDF Tools Functionality
function initPDFTools() {
    // DOM Elements
    const themeSwitch = document.getElementById('theme-switch');
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const mobileMenu = document.querySelector('.mobile-menu');
    const toolCards = document.getElementById('tools-container');
    const toolInterface = document.querySelector('.tool-interface');
    const toolsSection = document.querySelector('.tools-section');
    const backToToolsBtn = document.getElementById('back-to-tools');
    const currentToolName = document.getElementById('current-tool-name');
    const dropArea = document.getElementById('drop-area');
    const fileInput = document.getElementById('file-input');
    const browseBtn = document.getElementById('browse-btn');
    const filePreview = document.getElementById('file-preview');
    const toolOptions = document.getElementById('tool-options');
    const processBtn = document.getElementById('process-btn');
    const resetBtn = document.getElementById('reset-btn');
    const progressContainer = document.getElementById('progress-container');
    const progressBar = document.getElementById('progress-bar');
    const progressText = document.getElementById('progress-text');
    const resultSection = document.getElementById('result-section');
    const toolSearch = document.getElementById('tool-search');
    const toolCategory = document.getElementById('tool-category');
    const contactForm = document.getElementById('contact-form');
    
    // Current state
    let currentTool = null;
    let uploadedFiles = [];
    
    // Theme switcher
    if (themeSwitch) {
        const currentTheme = localStorage.getItem('theme') || 'light';
        if (currentTheme === 'dark') {
            themeSwitch.checked = true;
            document.documentElement.setAttribute('data-theme', 'dark');
        }
        
        themeSwitch.addEventListener('change', function() {
            if (this.checked) {
                document.documentElement.setAttribute('data-theme', 'dark');
                localStorage.setItem('theme', 'dark');
            } else {
                document.documentElement.removeAttribute('data-theme');
                localStorage.setItem('theme', 'light');
            }
        });
    }
    
    // Mobile menu toggle
    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', function() {
            mobileMenu.classList.toggle('active');
        });
        
        document.querySelectorAll('.mobile-menu a').forEach(link => {
            link.addEventListener('click', function() {
                mobileMenu.classList.remove('active');
            });
        });
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 70,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Tool data
    const tools = [
        { id: 'merge', name: 'Merge PDFs', icon: 'fa-file-pdf', category: 'organize', description: 'Combine multiple PDF files into one document.' },
        { id: 'split', name: 'Split PDF', icon: 'fa-cut', category: 'organize', description: 'Extract pages from a PDF or split into multiple documents.' },
        { id: 'compress', name: 'Compress PDF', icon: 'fa-compress-alt', category: 'edit', description: 'Reduce PDF file size without losing quality.' },
        { id: 'pdf-to-word', name: 'PDF to Word', icon: 'fa-file-word', category: 'convert', description: 'Convert your PDF to editable Word documents.' },
        { id: 'protect', name: 'Protect PDF', icon: 'fa-lock', category: 'security', description: 'Add password protection to your PDF file.' }
    ];
    
    // Render tools
    function renderTools(filter = '', category = 'all') {
        if (!toolCards) return;
        
        toolCards.innerHTML = '';
        
        const filteredTools = tools.filter(tool => {
            const matchesSearch = tool.name.toLowerCase().includes(filter.toLowerCase()) || 
                                 tool.description.toLowerCase().includes(filter.toLowerCase());
            const matchesCategory = category === 'all' || tool.category === category;
            return matchesSearch && matchesCategory;
        });
        
        if (filteredTools.length === 0) {
            toolCards.innerHTML = '<p class="no-results">No tools found matching your criteria.</p>';
            return;
        }
        
        filteredTools.forEach(tool => {
            const toolCard = document.createElement('div');
            toolCard.className = 'tool-card';
            toolCard.dataset.toolId = tool.id;
            
            toolCard.innerHTML = `
                <div class="tool-icon">
                    <i class="fas ${tool.icon}"></i>
                </div>
                <h3>${tool.name}</h3>
                <p>${tool.description}</p>
                <button class="btn btn-outline try-now-btn" data-tool-id="${tool.id}">Try Now</button>
            `;
            
            toolCards.appendChild(toolCard);
        });
        
        // Add event listeners to tool cards
        document.querySelectorAll('.tool-card, .try-now-btn').forEach(element => {
            element.addEventListener('click', function() {
                const toolId = this.dataset.toolId;
                selectTool(toolId);
            });
        });
    }
    
    // Initialize tools
    renderTools();
    
    // Tool search and filter
    if (toolSearch && toolCategory) {
        toolSearch.addEventListener('input', function() {
            renderTools(this.value, toolCategory.value);
        });
        
        toolCategory.addEventListener('change', function() {
            renderTools(toolSearch.value, this.value);
        });
    }
    
    // Select a tool
    function selectTool(toolId) {
        currentTool = tools.find(tool => tool.id === toolId);
        if (!currentTool) return;
        
        if (currentToolName) currentToolName.textContent = currentTool.name;
        if (toolsSection) toolsSection.style.display = 'none';
        if (toolInterface) toolInterface.style.display = 'block';
        
        resetToolInterface();
        generateToolOptions();
        
        window.scrollTo({
            top: toolInterface.offsetTop - 70,
            behavior: 'smooth'
        });
    }
    
    // Back to tools
    if (backToToolsBtn) {
        backToToolsBtn.addEventListener('click', function() {
            if (toolsSection) toolsSection.style.display = 'block';
            if (toolInterface) toolInterface.style.display = 'none';
            resetToolInterface();
            
            window.scrollTo({
                top: toolsSection.offsetTop - 70,
                behavior: 'smooth'
            });
        });
    }
    
    // Reset tool interface
    function resetToolInterface() {
        uploadedFiles = [];
        if (filePreview) {
            filePreview.innerHTML = `
                <div class="no-file">
                    <i class="fas fa-file-pdf"></i>
                    <p>No file selected</p>
                </div>
            `;
        }
        
        if (toolOptions) {
            toolOptions.innerHTML = `
                <div class="no-tool-selected">
                    <i class="fas fa-tools"></i>
                    <p>Please select a tool from the tools section</p>
                </div>
            `;
        }
        
        if (processBtn) processBtn.disabled = true;
        if (progressContainer) progressContainer.style.display = 'none';
        
        if (resultSection) {
            resultSection.innerHTML = `
                <div class="no-result">
                    <i class="fas fa-file-download"></i>
                    <p>Your processed files will appear here</p>
                </div>
            `;
        }
    }
    
    // Generate tool-specific options
    function generateToolOptions() {
        if (!currentTool || !toolOptions) return;
        
        let optionsHTML = '';
        
        switch(currentTool.id) {
            case 'merge':
                optionsHTML = `
                    <div class="option-group">
                        <h4><i class="fas fa-cog"></i> Merge Options</h4>
                        <div class="option-row">
                            <input type="checkbox" id="merge-remove-blank" checked>
                            <label for="merge-remove-blank">Remove blank pages</label>
                        </div>
                    </div>
                `;
                break;
                
            case 'split':
                optionsHTML = `
                    <div class="option-group">
                        <h4><i class="fas fa-cog"></i> Split Options</h4>
                        <div class="input-group">
                            <label for="split-range">Page Range (e.g., 1-3,5,7-9)</label>
                            <input type="text" id="split-range" placeholder="Enter page range">
                        </div>
                    </div>
                `;
                break;
                
            case 'compress':
                optionsHTML = `
                    <div class="option-group">
                        <h4><i class="fas fa-cog"></i> Compression Options</h4>
                        <div class="input-group">
                            <label for="compression-level">Compression Level</label>
                            <select id="compression-level">
                                <option value="low">Low (minimum compression)</option>
                                <option value="medium" selected>Medium (recommended)</option>
                                <option value="high">High (maximum compression)</option>
                            </select>
                        </div>
                    </div>
                `;
                break;
                
            case 'protect':
                optionsHTML = `
                    <div class="option-group">
                        <h4><i class="fas fa-cog"></i> Protection Options</h4>
                        <div class="input-group">
                            <label for="protect-password">Password</label>
                            <input type="password" id="protect-password" placeholder="Enter password">
                        </div>
                        <div class="input-group">
                            <label for="protect-confirm-password">Confirm Password</label>
                            <input type="password" id="protect-confirm-password" placeholder="Confirm password">
                        </div>
                    </div>
                `;
                break;
                
            default:
                optionsHTML = `
                    <div class="option-group">
                        <h4><i class="fas fa-cog"></i> Options</h4>
                        <p>No additional options available for this tool.</p>
                    </div>
                `;
        }
        
        toolOptions.innerHTML = optionsHTML;
    }
    
    // File upload handling
    if (browseBtn && fileInput) {
        browseBtn.addEventListener('click', function() {
            fileInput.click();
        });
        
        fileInput.addEventListener('change', function() {
            if (this.files.length > 0) {
                handleFiles(this.files);
            }
        });
    }
    
    // Drag and drop
    if (dropArea) {
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, preventDefaults, false);
        });
        
        ['dragenter', 'dragover'].forEach(eventName => {
            dropArea.addEventListener(eventName, highlight, false);
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, unhighlight, false);
        });
        
        dropArea.addEventListener('drop', function(e) {
            const dt = e.dataTransfer;
            const files = dt.files;
            if (files.length > 0) {
                handleFiles(files);
            }
        });
    }
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    function highlight() {
        if (dropArea) dropArea.classList.add('highlight');
    }
    
    function unhighlight() {
        if (dropArea) dropArea.classList.remove('highlight');
    }
    
    // Handle uploaded files
    function handleFiles(files) {
        uploadedFiles = [];
        const pdfFiles = Array.from(files).filter(file => file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf'));
        
        if (pdfFiles.length === 0) {
            alert('Please upload PDF files only.');
            return;
        }
        
        if (pdfFiles.length > 1 && !['merge'].includes(currentTool.id)) {
            alert(`This tool only supports single PDF files. Please upload one file at a time.`);
            return;
        }
        
        uploadedFiles = pdfFiles;
        updateFilePreview();
        if (processBtn) processBtn.disabled = false;
    }
    
    // Update file preview
    function updateFilePreview() {
        if (!filePreview) return;
        
        if (uploadedFiles.length === 0) {
            filePreview.innerHTML = `
                <div class="no-file">
                    <i class="fas fa-file-pdf"></i>
                    <p>No file selected</p>
                </div>
            `;
            return;
        }
        
        let filesHTML = '';
        
        uploadedFiles.forEach((file) => {
            filesHTML += `
                <div class="file-info">
                    <h4><i class="fas fa-file-pdf"></i> ${file.name}</h4>
                    <div class="file-details">
                        <div class="file-detail">
                            <span>Size:</span>
                            <span>${formatFileSize(file.size)}</span>
                        </div>
                        <div class="file-detail">
                            <span>Type:</span>
                            <span>PDF</span>
                        </div>
                    </div>
                </div>
            `;
        });
        
        filePreview.innerHTML = filesHTML;
    }
    
    // Format file size
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    // Reset button
    if (resetBtn) {
        resetBtn.addEventListener('click', resetToolInterface);
    }
    
    // Process button
    if (processBtn) {
        processBtn.addEventListener('click', processFiles);
    }
    
    // Process files based on selected tool
    async function processFiles() {
        if (uploadedFiles.length === 0) {
            alert('Please upload files first.');
            return;
        }
        
        // Validate options for specific tools
        if (currentTool.id === 'protect') {
            const password = document.getElementById('protect-password')?.value;
            const confirmPassword = document.getElementById('protect-confirm-password')?.value;
            
            if (!password || !confirmPassword) {
                alert('Please enter and confirm the password.');
                return;
            }
            
            if (password !== confirmPassword) {
                alert('Passwords do not match.');
                return;
            }
        }
        
        // Show progress bar
        if (progressContainer) progressContainer.style.display = 'block';
        if (progressBar) progressBar.style.width = '0%';
        if (progressText) progressText.textContent = '0%';
        
        // Simulate processing
        let progress = 0;
        const interval = setInterval(() => {
            progress += 5;
            if (progress > 100) progress = 100;
            
            if (progressBar) progressBar.style.width = progress + '%';
            if (progressText) progressText.textContent = progress + '%';
            
            if (progress === 100) {
                clearInterval(interval);
                showResult();
            }
        }, 100);
    }
    
    // Show processing result
    function showResult() {
        if (!resultSection) return;
        
        let resultHTML = `
            <div class="result-content">
                <h3><i class="fas fa-check-circle" style="color: var(--success-color);"></i> Processing Complete</h3>
                <p>Your ${currentTool.name} operation was successful.</p>
                <button class="btn btn-primary download-btn" id="download-result">
                    <i class="fas fa-download"></i> Download Result
                </button>
            </div>
        `;
        
        resultSection.innerHTML = resultHTML;
        
        // Add download event listener
        const downloadBtn = document.getElementById('download-result');
        if (downloadBtn) {
            downloadBtn.addEventListener('click', function() {
                alert('In a real application, this would download the processed file. This is a demo.');
            });
        }
    }
    
    // Contact form
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('name')?.value;
            const email = document.getElementById('email')?.value;
            const message = document.getElementById('message')?.value;
            
            if (!name || !email || !message) {
                alert('Please fill in all required fields.');
                return;
            }
            
            alert(`Thank you for your message, ${name}! We'll get back to you soon.`);
            this.reset();
        });
    }
}